#!/bin/sh
curl -f http://localhost:8080/health || exit 1
