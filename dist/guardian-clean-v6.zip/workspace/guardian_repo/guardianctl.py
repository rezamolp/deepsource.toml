#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Optional


REPO_ROOT = Path(__file__).resolve().parent
PID_FILE = REPO_ROOT / ".guardian.pid"
LOG_FILE = REPO_ROOT / "guardian.log"


def _print(msg: str) -> None:
    print(msg, flush=True)


def _is_pid_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def _read_pid() -> Optional[int]:
    try:
        if PID_FILE.exists():
            pid = int(PID_FILE.read_text().strip())
            return pid
    except Exception:
        return None
    return None


def _write_pid(pid: int) -> None:
    PID_FILE.write_text(str(pid))


def _remove_pid_file() -> None:
    try:
        PID_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def _run(cmd: list[str], env: Optional[dict[str, str]] = None) -> int:
    _print(f"$ {' '.join(cmd)}")
    proc = subprocess.run(cmd, cwd=str(REPO_ROOT), env=env)
    return proc.returncode


def _kill_pid(pid: int, sig: int = signal.SIGKILL) -> None:
    try:
        os.kill(pid, sig)
    except Exception:
        pass


def _pids_matching_patterns(patterns: list[str]) -> list[int]:
    pids: list[int] = []
    try:
        out = subprocess.check_output(["ps", "-eo", "pid,command"], text=True)
        for line in out.splitlines():
            line = line.strip()
            if not line or line.startswith("PID"):
                continue
            try:
                pid_str, cmd = line.split(None, 1)
                pid = int(pid_str)
            except Exception:
                continue
            for pat in patterns:
                if pat in cmd:
                    pids.append(pid)
                    break
    except Exception:
        pass
    return pids


def _free_port(port: int) -> None:
    # Try lsof
    try:
        out = subprocess.check_output(["bash", "-lc", f"lsof -i :{port} -t"], text=True)
        for line in out.splitlines():
            pid = int(line.strip())
            _kill_pid(pid)
    except Exception:
        pass
    # Try ss
    try:
        out = subprocess.check_output(["bash", "-lc", "ss -ltnp"], text=True)
        for line in out.splitlines():
            if f":{port} " in line or f":{port}\n" in line:
                # ... users:(("python3",pid=1234, ...))
                if "pid=" in line:
                    try:
                        pid_part = line.split("pid=")[1]
                        pid = int(pid_part.split(",")[0].split(")")[0])
                        _kill_pid(pid)
                    except Exception:
                        continue
    except Exception:
        pass


def hard_stop_all(_: argparse.Namespace) -> None:
    # Stop by PID file if present
    stop(SimpleNamespace())
    # Kill any stray guardian processes
    patterns = [
        "-m guardian.main",
        "/guardian/guardian/main.py",
        str(REPO_ROOT / "guardian/main.py"),
        "guardian_repo/guardian/main.py",
    ]
    for pid in set(_pids_matching_patterns(patterns)):
        if _is_pid_running(pid):
            _print(f"Killing stray PID {pid} ...")
            _kill_pid(pid)
    # Try pkill as an additional safeguard
    try:
        subprocess.run(["bash", "-lc", "pkill -f 'python.*guardian\\.main' || true"], check=False)
        subprocess.run(["bash", "-lc", "pkill -f 'guardian/guardian/main\\.py' || true"], check=False)
    except Exception:
        pass
    # Free health port
    port = int(os.getenv("HEALTH_PORT", "8080"))
    _free_port(port)


def install(args: argparse.Namespace) -> None:
    # Prefer user site on Debian with PEP 668
    cmd = [sys.executable, "-m", "pip", "install", "--user", "--break-system-packages", "-r", "requirements.txt"]
    code = _run(cmd)
    if code != 0:
        sys.exit(code)


def migrate(args: argparse.Namespace) -> None:
    code = _run([sys.executable, "-m", "guardian.db.migrate"])
    if code != 0:
        sys.exit(code)


def cleanup(args: argparse.Namespace) -> None:
    # Remove caches
    removed = []
    for name in ["__pycache__", ".pytest_cache"]:
        for p in REPO_ROOT.rglob(name):
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
                removed.append(str(p))
    _print(f"Removed caches: {len(removed)}")
    # Clean stale pid
    pid = _read_pid()
    if pid and not _is_pid_running(pid):
        _remove_pid_file()
        _print("Removed stale PID file")


def status(args: argparse.Namespace) -> None:
    pid = _read_pid()
    if pid and _is_pid_running(pid):
        _print(f"Guardian running with PID {pid}")
    else:
        _print("Guardian is not running")


def stop(args: argparse.Namespace) -> None:
    pid = _read_pid()
    if pid and _is_pid_running(pid):
        _print(f"Stopping PID {pid} ...")
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            pass
        # Wait up to 5s
        for _ in range(50):
            if not _is_pid_running(pid):
                break
            time.sleep(0.1)
        if _is_pid_running(pid):
            _print("Force killing ...")
            try:
                os.kill(pid, signal.SIGKILL)
            except Exception:
                pass
        _remove_pid_file()
        _print("Stopped")
    else:
        _print("No running process found")


def start(args: argparse.Namespace) -> None:
    # Ensure clean state
    cleanup(args)
    # Migrate
    migrate(args)
    # If already running, stop
    pid = _read_pid()
    if pid and _is_pid_running(pid):
        _print("Service already running. Restarting ...")
        stop(args)

    # Start
    logf = open(LOG_FILE, "a")
    env = os.environ.copy()
    # Load .env to environment without exposing secrets in logs
    dotenv_path = REPO_ROOT / ".env"
    if dotenv_path.exists():
        for line in dotenv_path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            env.setdefault(key, value)
    proc = subprocess.Popen([sys.executable, "-m", "guardian.main"], cwd=str(REPO_ROOT), stdout=logf, stderr=subprocess.STDOUT, env=env)
    _write_pid(proc.pid)
    _print(f"Started PID {proc.pid}")
    time.sleep(1.0)
    # Quick health probe
    health(args)
    if getattr(args, "follow", False):
        # Tail logs after start
        logs(SimpleNamespace(follow=True, lines=200))


def console(args: argparse.Namespace) -> None:
    # Foreground run with live logs in console
    cleanup(args)
    migrate(args)
    env = os.environ.copy()
    dotenv_path = REPO_ROOT / ".env"
    if dotenv_path.exists():
        for line in dotenv_path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            env.setdefault(key, value)
    _print("Starting in console (foreground)... press Ctrl+C to stop")
    code = subprocess.call([sys.executable, "-m", "guardian.main"], cwd=str(REPO_ROOT), env=env)
    sys.exit(code)


def restart(args: argparse.Namespace) -> None:
    stop(args)
    start(args)


def logs(args: argparse.Namespace) -> None:
    if not LOG_FILE.exists():
        _print("No log file yet.")
        return
    if args.follow:
        # Simple tail -f implementation
        with open(LOG_FILE, "r") as f:
            f.seek(0, os.SEEK_END)
            while True:
                line = f.readline()
                if not line:
                    time.sleep(0.2)
                    continue
                sys.stdout.write(line)
                sys.stdout.flush()
    else:
        data = LOG_FILE.read_text().splitlines()[-args.lines:]
        print("\n".join(data))


def test_cmd(args: argparse.Namespace) -> None:
    code = _run([str(Path.home() / ".local/bin/pytest"), "-q"]) if (Path.home() / ".local/bin/pytest").exists() else _run([sys.executable, "-m", "pytest", "-q"])
    if code != 0:
        sys.exit(code)


def health(args: argparse.Namespace) -> None:
    host = os.getenv("HEALTH_HOST", "127.0.0.1")
    port = int(os.getenv("HEALTH_PORT", "8080"))
    import urllib.request
    url = f"http://{host}:{port}/healthz"
    try:
        with urllib.request.urlopen(url, timeout=2) as resp:
            body = resp.read().decode("utf-8", errors="ignore")
            _print(f"Health {resp.status}: {body}")
    except Exception as ex:
        _print(f"Health check failed: {ex}")


def set_target(args: argparse.Namespace) -> None:
    # Set target_chat_id in DB settings
    from guardian.db.base import create_session_factory
    from guardian.db.models import Base
    from guardian.db.repo import Repository
    # Load env to get DATABASE_URL if provided
    dotenv_path = REPO_ROOT / ".env"
    if dotenv_path.exists():
        for line in dotenv_path.read_text().splitlines():
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key, value)
    database_url = os.getenv("DATABASE_URL", "sqlite:///guardian.sqlite3")
    SessionLocal, engine = create_session_factory(database_url)
    Base.metadata.create_all(engine)
    repo = Repository(SessionLocal())
    repo.set_setting("target_chat_id", str(args.chat_id))
    _print(f"target_chat_id set to {args.chat_id}")


def interactive_menu() -> None:
    while True:
        print("\n=== Guardian Runner ===")
        print("1) Start (console)")
        print("2) Start (background) and follow logs")
        print("3) Hard stop all")
        print("4) Status")
        print("5) Logs (follow)")
        print("6) Health check")
        print("7) Set target chat id")
        print("8) Version show")
        print("9) Exit")
        choice = input("Select: ").strip()
        if choice == "1":
            hard_stop_all(SimpleNamespace())
            try:
                console(SimpleNamespace())
            except SystemExit:
                pass
        elif choice == "2":
            hard_stop_all(SimpleNamespace())
            start(SimpleNamespace(follow=True))
        elif choice == "3":
            hard_stop_all(SimpleNamespace())
        elif choice == "4":
            status(SimpleNamespace())
        elif choice == "5":
            logs(SimpleNamespace(follow=True, lines=200))
        elif choice == "6":
            health(SimpleNamespace())
        elif choice == "7":
            val = input("Enter chat_id (e.g. -100123...): ").strip()
            try:
                cid = int(val)
            except Exception:
                print("Invalid chat id")
                continue
            set_target(SimpleNamespace(chat_id=cid))
        elif choice == "8":
            from guardian.version import get_version
            print(get_version())
        elif choice == "9":
            break
        else:
            print("Invalid choice")


def main() -> None:
    parser = argparse.ArgumentParser(description="Guardian control CLI")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("install").set_defaults(func=install)
    sub.add_parser("migrate").set_defaults(func=migrate)
    sub.add_parser("cleanup").set_defaults(func=cleanup)
    sub.add_parser("status").set_defaults(func=status)
    sub.add_parser("stop").set_defaults(func=stop)
    p_start = sub.add_parser("start")
    p_start.add_argument("--follow", "-f", action="store_true")
    p_start.set_defaults(func=start)
    sub.add_parser("console").set_defaults(func=console)
    sub.add_parser("hard-stop").set_defaults(func=hard_stop_all)
    sub.add_parser("restart").set_defaults(func=restart)
    p_logs = sub.add_parser("logs")
    p_logs.add_argument("--follow", "-f", action="store_true")
    p_logs.add_argument("--lines", "-n", type=int, default=200)
    p_logs.set_defaults(func=logs)
    sub.add_parser("test").set_defaults(func=test_cmd)
    sub.add_parser("health").set_defaults(func=health)
    p_set = sub.add_parser("set-target")
    p_set.add_argument("chat_id", type=int)
    p_set.set_defaults(func=set_target)

    # version subcommands
    from guardian.version import get_version
    def version_show(_: argparse.Namespace) -> None:
        _print(get_version())
    def version_set(args: argparse.Namespace) -> None:
        (REPO_ROOT / "VERSION").write_text(str(args.number))
        _print(f"Version set to {args.number}")
    def version_bump(_: argparse.Namespace) -> None:
        cur = int(get_version() or 0)
        new = cur + 1
        (REPO_ROOT / "VERSION").write_text(str(new))
        _print(f"Version bumped to {new}")
    p_ver = sub.add_parser("version")
    pv = p_ver.add_subparsers(dest="vcmd", required=True)
    pv.add_parser("show").set_defaults(func=version_show)
    pvs = pv.add_parser("set")
    pvs.add_argument("number", type=int)
    pvs.set_defaults(func=version_set)
    pv.add_parser("bump").set_defaults(func=version_bump)

    if len(sys.argv) == 1:
        interactive_menu()
        return
    args = parser.parse_args()
    if hasattr(args, "func"):
        args.func(args)
    else:
        interactive_menu()


if __name__ == "__main__":
    main()
