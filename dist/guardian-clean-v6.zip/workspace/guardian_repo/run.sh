#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

CMD=${1:-help}
shift || true

case "$CMD" in
  install)
    ./guardianctl.py install
    ;;
  migrate)
    ./guardianctl.py migrate
    ;;
  start)
    ./guardianctl.py start
    ;;
  stop)
    ./guardianctl.py stop
    ;;
  restart)
    ./guardianctl.py restart
    ;;
  status)
    ./guardianctl.py status
    ;;
  logs)
    ./guardianctl.py logs "$@"
    ;;
  health)
    ./guardianctl.py health
    ;;
  set-target)
    ./guardianctl.py set-target "$@"
    ;;
  test)
    ./guardianctl.py test
    ;;
  cleanup)
    ./guardianctl.py cleanup
    ;;
  *)
    echo "Usage: $0 {install|migrate|start|stop|restart|status|logs|health|set-target <chat_id>|test|cleanup}"
    exit 1
    ;;
esac
