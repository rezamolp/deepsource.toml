# Changelog

## 1 - Initial versioning
- Added VERSION file and version module
- Exposed version in admin Status screen and startup logs
- guardianctl: version show/set/bump commands
- Added run.sh and run.bat wrappers
- Added guardianctl management CLI