@echo off
setlocal enabledelayedexpansion
cd /d %~dp0

set CMD=%1
if "%CMD%"=="" goto :usage
shift

if "%CMD%"=="install" (
  py -3 guardianctl.py install
  goto :eof
)
if "%CMD%"=="migrate" (
  py -3 guardianctl.py migrate
  goto :eof
)
if "%CMD%"=="start" (
  py -3 guardianctl.py start
  goto :eof
)
if "%CMD%"=="stop" (
  py -3 guardianctl.py stop
  goto :eof
)
if "%CMD%"=="restart" (
  py -3 guardianctl.py restart
  goto :eof
)
if "%CMD%"=="status" (
  py -3 guardianctl.py status
  goto :eof
)
if "%CMD%"=="logs" (
  py -3 guardianctl.py logs %*
  goto :eof
)
if "%CMD%"=="health" (
  py -3 guardianctl.py health
  goto :eof
)
if "%CMD%"=="set-target" (
  py -3 guardianctl.py set-target %*
  goto :eof
)
if "%CMD%"=="test" (
  py -3 guardianctl.py test
  goto :eof
)
if "%CMD%"=="cleanup" (
  py -3 guardianctl.py cleanup
  goto :eof
)

:usage
echo Usage: run.bat ^<install^|migrate^|start^|stop^|restart^|status^|logs^|health^|set-target chat_id^|test^|cleanup^>
exit /b 1
